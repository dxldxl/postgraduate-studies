package com.crouse.crouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
