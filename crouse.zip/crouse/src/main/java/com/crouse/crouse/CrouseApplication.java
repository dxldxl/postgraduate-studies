package com.crouse.crouse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrouseApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrouseApplication.class, args);
	}

}
